Store all files related to Final Report.
