# B'dazzled Blue Maze Solver

This is the repository for the B'dazzled Blue SYSC 4805 Term Project. The project involves a Robot (Arduino based) so9lving a maze of Black Lines until an objective is found. 

#Team Members: 
  - Samy Ibrahim (101037927) 
  - Muhammad Tarequzzaman (100954008) 
  - Jacob Martin (10100849) 
  - Ahmad Chaudhry (101003005) 

